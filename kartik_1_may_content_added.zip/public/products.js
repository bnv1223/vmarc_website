

const products = [
    ltCables = [
        "LT-PVC-POWER-CONTROL-CABLES",
        "LT-XLPE-POWER-CONTROL-CABLES",
        "LT-XLPE-AERIAL-BUNCHED-CABLES"
    ],
    lightdutycables = [
        "3-CORE-FLAT-PVC-XLPE-CABLES"
        , "SINGLE-MULTICORE-ALUMINIUM-CABLES",
        "SINGLE-MULTICORE-COPPER-CABLES",
        "HFFR-ZHFR-LSZH MULTISTRAND-CABLES",
        "FRLSH-MULTISTRAND-CABLES",
        "FR-MULTISTRAND-CABLES"
    ],
    htCables = [
        "HT-CABLES-UPTO-33-KV",
        "MEDIUM-VOLTAGE-COVERED-CONDUCTORS"
    ],
    communicationCable = [
        "cctv-cables",
        "CO-AXIAL-CABLES",
        "LAN-CABLES",
        "TELEPHONE-SWITCHBOARD-CABLES",
    ]
]